package com.zemoso.ums.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserInfoDto {
    private Long userId;
    private String firstName;
    private String lastName;
}
