package com.zemoso.ums.services;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserServiceImplTest {
    private UserService userService;
    UserServiceImplTest(UserService userService){
        this.userService = userService;
    }

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void findAll() {
    }

    @Test
    void getOne() {
    }

    @Test
    void create() {
    }

    @Test
    void deleteById() {
    }

    @Test
    void update() {
    }
}